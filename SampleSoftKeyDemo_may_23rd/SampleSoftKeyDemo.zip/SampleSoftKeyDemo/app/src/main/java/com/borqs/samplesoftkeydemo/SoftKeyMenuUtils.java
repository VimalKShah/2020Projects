package com.borqs.samplesoftkeydemo;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;


public class SoftKeyMenuUtils {
    private static final String LOG_TAG = "DemoSoftKeyMenuUtils";

    public static void setSoftKeyMenuLabels(Context context, String leftLabel, String centerLabel,
                                            String rightLabel, boolean rightFocus) {
        Intent intent = new Intent("android.intent.action.CHANGE_NAVBAR");
        intent.putExtra("left", leftLabel);
        intent.putExtra("center", centerLabel);
        intent.putExtra("right", rightLabel);
        intent.putExtra("right_focus", rightFocus);
        context.sendBroadcast(intent);
    }

    // remove TextView from function when used in production code
    public static void setLSKMenuLabels(Context context, String leftLabel) {
        Intent intent = new Intent("android.intent.action.CHANGE_NAVBAR");
        intent.putExtra("left", leftLabel);
        context.sendBroadcast(intent);
    }

    public static void setCSKMenuLabels(Context context, String centerLabel) {
        Log.e(LOG_TAG, "RSK intent sent  -->"+centerLabel);
        Intent intent = new Intent("android.intent.action.CHANGE_NAVBAR");
        intent.putExtra("center", centerLabel);
        context.sendBroadcast(intent);
    }

    // remove TextView from function when used in production code
    public static void setRSKMenuLabels(Context context, String rightLabel) {
        Log.e(LOG_TAG, "RSK intent sent  -->"+rightLabel);
        Intent intent = new Intent("android.intent.action.CHANGE_NAVBAR");
        intent.putExtra("right", rightLabel);
        context.sendBroadcast(intent);
    }
}
